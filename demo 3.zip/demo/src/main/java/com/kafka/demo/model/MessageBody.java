package com.kafka.demo.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class MessageBody {
    private String po;
    private String dc;
}
