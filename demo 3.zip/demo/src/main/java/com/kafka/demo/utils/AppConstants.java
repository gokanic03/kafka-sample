package com.kafka.demo.utils;

public class AppConstants {
    public static final String TOPIC_NAME = "spring_topics";
    public static final String GROUP_ID = "cg1";
}
